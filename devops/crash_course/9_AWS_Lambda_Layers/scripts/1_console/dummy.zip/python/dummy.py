def foo():
    print('bar')